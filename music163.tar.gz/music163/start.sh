#!/bin/sh
mainPath=/root/music163
appjsDir=$mainPath/UnblockNeteaseMusic-master
port=10620

#get ip
music163ip=$(ping music.163.com -c1 | grep from | awk '{ print $4 }'|cut -d: -f1)
echo "music.163.com --->  $music163ip"

# open port
sudo /etc/init.d/iptables stop
service iptables stop
echo "iptables stop"

#run app.js
echo "Launching app"
cd $appjsDir
$mainPath/node $appjsDir/app.js -p $port -f $music163ip
