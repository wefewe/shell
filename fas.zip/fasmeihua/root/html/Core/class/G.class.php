<?php
$haicurl = md5($_SERVER["HTTP_HOST"]);
$curl = curl_init();
$urllink = "http://shouquan.sutuo.club/ymsq_domain.php";
curl_setopt($curl, CURLOPT_URL, $urllink);
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
$data = curl_exec($curl);
curl_close($curl);
$back = explode(",", $data);
$file = "http://shouquan.sutuo.club/ymsq_config.php";
$content = file_get_contents($file);
$backa = explode("f--f", $content);
$sqfs = $backa[0];
$xiana = $backa[1];
$xianb = $backa[2];
if (in_array($haicurl, $back)) {
} else {
	if ($sqfs == '1') {
		echo "<div style='margin:120px 100px;padding:50px;border:3px dashed #ccc;line-height:30px;text-align:center;font-family:microsoft yahei;'><h1 style='font-size:22px;line-height:190%;'>$xiana</h1></div>";
	} else {
		header("Location:$xianb");
	}
	exit;
}
?><?php 