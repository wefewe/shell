<?php

	include('head.php');

	include('nav.php');

	$m = new Map();

 	if($_GET['act'] == 'update'){

		



		$info = file_put_contents("../adminqq.txt",$_POST["content"]);

 		

		tip_success("修改成功",$_SERVER['HTTP_REFERER']);

		

	}else{

		$action = "?act=update";

		

		$info = file_get_contents("../adminqq.txt");

		//$p = '/default\s([0-9]*)/';

	//preg_match($p,$info,$m);



 ?>

             <div class="row">

                <div class="col-md-12">

				<center>

                    <div class="panel panel-default">

                        <div class="panel-heading">管理员QQ设置</div>

                        <div class="panel-body">

                            <form role="form" class="form-inline" method="POST" action="<?php echo $action?>">

                                <div class="form-group">

                                    <label for="input-email" class="sr-only">请输入QQ号码</label>

                                    <input rows="10" name="content" placeholder="<?php echo $info ?>" class="form-control">

                                </div>



<br/><br/>

                                <button type="submit" class="btn btn-primary" style="width:204px">设置</button>

                            </form>

                        </div>

                    </div>

					</center>

                </div>

            </div>



        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>

<?php

	}

	include('footer.php');

?>

<?php 