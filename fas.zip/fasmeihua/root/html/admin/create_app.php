<?php
include('head.php');
include('nav.php');
?>
<script>
window.location.href='https://www.dingd.cn/app/';
</script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php include("footer.php");?><?php 