<?php
require dirname(dirname( __FILE__))."/system.php";
if(db("app_admin")->getnums()>1){
	die("Sorry，you admin user has more than one.Please check you Mysql for app_admin table.");
};	
if(!$display_login)
{
	$admin = db("app_admin")->where(["username"=>$_SESSION["dd"]["username"],"password"=>$_SESSION["dd"]["password"]])->find();
	if(!$admin)
	{
		header("location:login.php");	
		exit;
	}
}
$servertitle = file_get_contents("../servertitle.txt");
$serverlogo = file_get_contents("../serverlogo.txt");
$usergg = file_get_contents("../usergg.txt");
$buykami = file_get_contents("../buykami.txt");
$dailigg = file_get_contents("../dailigg.txt");
$userappdown = file_get_contents("../userappdown.txt");
$usertiaokuan = file_get_contents("../usertiaokuan.txt");
$userhelp = file_get_contents("../userhelp.txt");
$userczsm = file_get_contents("../userczsm.txt");
$adminqq = file_get_contents("../adminqq.txt");
$serverdomain = file_get_contents("../serverdomain.txt");
$servercopy = file_get_contents("../servercopy.txt");
?>