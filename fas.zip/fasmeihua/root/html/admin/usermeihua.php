<?php
	include('head.php');
	include('nav.php');
	$m = new Map();
 	if($_GET['act'] == 'update'){
		

		$usergg = file_put_contents("../usergg.txt",$_POST["usergg"]);
		$userczsm = file_put_contents("../userczsm.txt",$_POST["userczsm"]);
		$buykami = file_put_contents("../buykami.txt",$_POST["buykami"]);
		$userhelp = file_put_contents("../userhelp.txt",$_POST["userhelp"]);
		$usertiaokuan = file_put_contents("../usertiaokuan.txt",$_POST["usertiaokuan"]);
		$userappdown = file_put_contents("../userappdown.txt",$_POST["userappdown"]);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$usergg = file_get_contents("../usergg.txt");
		$userczsm = file_get_contents("../userczsm.txt");
		$buykami = file_get_contents("../buykami.txt");
		$userhelp = file_get_contents("../userhelp.txt");
		$usertiaokuan = file_get_contents("../usertiaokuan.txt");
		$userappdown = file_get_contents("../userappdown.txt");
		//$p = '/default\s([0-9]*)/';
	//preg_match($p,$info,$m);

 ?>
             <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            用户中心公告调用API设置
                        </div>
                        <div class="panel-body">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>">

            <div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心首页动态公告调用API</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="usergg" value="<?php echo $usergg ?>">
				</div>
			</div>
            <div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心充值下方充值说明文档</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="userczsm" value="<?php echo $userczsm ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心卡密购买链接</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="buykami" value="<?php echo $buykami ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心新手帮助链接</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="userhelp" value="<?php echo $userhelp ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心用户条款链接</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="usertiaokuan" value="<?php echo $usertiaokuan ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">用户中心APP下载链接</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="userappdown" value="<?php echo $userappdown ?>">
				</div>
			</div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
			<button type="submit" class="btn btn-info btn-block">设置</button>
			</div>
	</div>
	</form> 
	</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
	}
	include('footer.php');
?>
<?php 