<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
$key = file_get_contents("/root/res/app_key.txt");
?>
<div class="" >
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            代理列表
                        </div>
                        <div class="panel-body">
<?php
if($_GET["act"]=='del'){
	if(db("app_daili")->where(array("id"=>$_GET['id']))->delete()){
		tip_success("操作成功！",$_SERVER['HTTP_REFERER']);
	}else{
		tip_failed("十分抱歉修改失败",$_SERVER['HTTP_REFERER']);
	}
}

else
{

echo '<form action="?" method="get" class="form-inline">
  <div class="col-sm-12">
    <input type="text" class="form-control" style="width:100%" name="kw" placeholder="账号">
	<button type="submit" class="btn btn-primary" style="width:100%">搜索</button>
  </div>
  <div style="clear:both;height:20px;"></div>
  ';
if(!empty($_GET['kw'])) {
	$numrows = db("app_daili")->where(array("name"=>$_GET["kw"]))->getnums();
	$where = array("name"=>$_GET["kw"]);
	$con='<div class="col-sm-12"><center><a href="#" class="btn btn-success" style="width:100%" >平台共有 <b>'.$numrows.'</b> 个账号</a></center></div>';
}else{
	$numrows = db("app_daili")->where()->getnums();
	$where= '';
	$con='<div class="col-sm-12"><center><a href="#" class="btn btn-success" style="width:100%">平台共有 <b>'.$numrows.'</b> 个账号</a></center></div>';
}
echo $con;
echo '</form>';


?>
<div style="clear:both;height:20px;"></div>
   <div class="col-sm-12">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
		  <tr>
		  <th width="50"><center>序号</center></th>
		  <th><center>账号</center></th>
		  <th><center>添加时间</center></th>
		  <th><center>到期时间</center></th>
		  <th><center>等级</center></th>
		  <th><center>余额</center></th>
		  <th><center>APP_KEY</center></th>
		  <th><center>状态</center></th>
		  <th><center>操作</center></th>
		  </tr>
		  </thead>
          <tbody>
<?php
$rs=db("app_daili")->where($where)->fpage($_GET["page"],30)->order("id DESC")->select();
$i = 1;
foreach($rs as $res)
{ 
	$deng=db("app_daili_type")->where(["id"=>$res["type"]])->find();

?>
	<tr class="line-id-<?=$res['id']?>">
	<td><center><?=$res['id']?></center></td>
	<td><center><?=$vip?><?=$res['name']?><?=$p?></center></td>
	<td><center><?=date("Y-m-d",$res['time'])?></center></td>
	<td><center><?=date("Y-m-d",$res['endtime'])?></center></td>
	<td><center><?=$deng["name"]?> 折扣：<?=$deng["per"]?>%</center></td>
	<td><center><span class="maxll"><?=$res['balance']?>元</center></td>
	<td><center><?php echo trim($key)."_".$res["id"];?></center></td>
	<td><center><?=($res['lock']?'开通':'禁用')?></center></td>
	<td><center><a class="btn btn-xs btn-success" href="dl_add.php?act=mod&id=<?=$res['id']?>">配置</a>&nbsp;<a href="?act=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}else{return true}">删除</a></center></td>
	</tr>

<?php 
	$i++;
}
?>
          </tbody>
        </table>
    </div>
	</div>
    </div>
	</div>
	    </div>
		    </div>
<?php echo create_page_html($numrows,$_GET["page"]);?>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php } include("footer.php");?>
<?php 