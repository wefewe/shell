       <aside class="float-navigation light-navigation">
            <div class="nano">
                <div class="nano-content">
                    <ul class="metisMenu nav" id="menu">
                        <li class="nav-heading"><span>流控管理菜单</span></li>
                        <li class="active">
                            <a href="index.php" aria-expanded="true"><i class="icon-home"></i> 流控首页 </a>
                        </li>
<!--                         <li>
						<a href="widgets.html"><i class="fa fa-diamond"></i> Widgets </a>
						</li> -->
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-user"></i> 用户管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="user_create.php" name="帐号批量生成">帐号批量生成</a></li>
                                <li><a href="userlastkm.php">上次生成</a></li>
                                <li><a href="user_add.php">新增用户</a></li>
								<li><a href="user_list.php">用户列表</a></li>
								<li><a href="online.php">在线用户</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-list"></i> 线路管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="zs.php">证书管理</a></li>
                                <li><a href="line_list.php">线路列表</a></li>
                                <li><a href="line_add.php">新增线路</a></li>
								<li><a href="cat_add.php">分类管理</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-basket"></i> 套餐管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="list_tc.php">套餐管理</a></li>
                                <li><a href="add_tc.php">新增套餐</a></li>
                                <li><a href="km_list.php">卡密管理</a></li>
                                <li><a href="kmlastkm.php">上次生成</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="fa fa-sitemap"></i> 负载管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="net.php">宽带监控</a></li>
                                <li><a href="note_add.php">新增节点</a></li>
                                <li><a href="note_list.php">节点管理</a></li>
                                <li><a href="fwq_add.php">新增服务器</a></li>
								<li><a href="fwq_list.php">服务器列表</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="fa fa-comments-o"></i> 消息管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="feedback.php">反馈管理</a></li>
                                <li><a href="list_gg.php">公告管理</a></li>
                                <li><a href="add_gg.php">发布新公告</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-screen-smartphone"></i> APP管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="create_app.php">APP生成</a></li>
                                <li><a href="qq_admin.php">APP设置</a></li>
                                <li><a href="AdminShengji.php">升级/推送</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-users"></i> 代理管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="type_add.php">新增级别</a></li>
                                <li><a href="type_list.php">级别列表</a></li>
                                <li><a href="dl_list.php">代理列表</a></li>
                                <li><a href="dl_add.php">新增代理</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-credit-card"></i> 交易管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="pay_user.php">收支管理</a></li>
                                <li><a href="goods.php">商品管理</a></li>
                                <li><a href="pay.php">参数设置</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-lock"></i> 安全管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="mysql.php">数据备份</a></li>
                                <li><a href="hosts.php">DNS拦截</a></li>
                                <li><a href="user.php">密码修改</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-wrench"></i> 高级设置 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="safe.php">高级管理</a></li>
                                <li><a href="float.php">限速管理</a></li>
                            </ul>
                        </li>
                        <li class="nav-heading"><span>第三方美化设置</span></li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-settings"></i> 用户中心美化 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="false">
                                <li><a href="usermeihua.php">用户中心美化设置</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-settings"></i> 代理中心美化 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="false">
                                <li><a href="dailimeihua.php">用户中心美化设置</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-pencil"></i> 全局资料设置 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="servermeihua.php">站点全局设置</a></li>
                            </ul>
                        </li>
                        <!--<li><a href="landing/index.html" target="_blank" class="bg-primary"><i class="icon-star"></i>Landing page</a></li>-->
                    </ul>
                </div><!--nano content-->
            </div><!--nano scroll end-->
        </aside><?php 