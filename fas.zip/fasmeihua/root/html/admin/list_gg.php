<?php
include('head.php');
	
 	include('nav.php');
 	if($_GET['act'] == 'del'){
		$db = db('app_gg');
		if($db->where(array('id'=>$_POST['id']))->delete()){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}elseif($_GET['act'] == 'show'){
		$show = $_POST['show'] == '1' ? "1" : "0";
		$db = db('app_gg');
		if($db->where(array('id'=>$_POST['id']))->update(array('show'=>$show))){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}else{
 ?>
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            公告列表
                        </div>
                        <div class="panel-body">
	<ul class="list-group">
	<?php 
		$db = db('app_gg');
		$list = $db->where(array("daili"=>0))->order('id DESC')->select();
		foreach($list as $vo){
			echo ' <li class="list-group-item line-id-'.$vo['id'].'">
        <span class="badge">'.date('Y/m/d H:i:s',$vo['time']).'</span>
        公告编号ID：'.$vo['id'].'<br/>标题：'.$vo['name'].'<br/>
		<div align="right">
		<button type="button" class="btn btn-primary btn-xs" onclick="window.location.href=\'add_gg.php?act=mod&id='.$vo['id'].'\'">编辑</button>&nbsp;';
		echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\''.$vo['id'].'\')">删除</button>
		</div>
    </li>';
		}
	?>
   
</ul>
</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
	}
	include('footer.php');
	
?>
<script>
function qiyong(id){

	var doc = $('.line-id-'+id+' .showstatus');
	if(doc.attr('data') == "1"){
		doc.html("已禁用").attr({'data':'0'});
	}else{
		doc.html("已启用").attr({'data':'1'});
	}
	var url = "list_gg.php?act=show";
		var data = {
			"id":id,
			"show":doc.attr('data')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}
function delLine(id){
	if(confirm('确认删除吗？删除后不可恢复哦！')){
		$('.line-id-'+id).slideUp();
		var url = "list_gg.php?act=del";
		var data = {
			"id":id
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("删除失败");
			}
		},"JSON");
	}
}
</script><?php 