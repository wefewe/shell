<?php
	include('head.php');
	include('nav.php');
	$m = new Map();
 	if($_GET['act'] == 'update'){
		

		$servertitle = file_put_contents("../servertitle.txt",$_POST["servertitle"]);
		$serverlogo = file_put_contents("../serverlogo.txt",$_POST["serverlogo"]);
		$adminqq = file_put_contents("../adminqq.txt",$_POST["adminqq"]);
		$serverdomain = file_put_contents("../serverdomain.txt",$_POST["serverdomain"]);
		$servercopy = file_put_contents("../servercopy.txt",$_POST["servercopy"]);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$servertitle = file_get_contents("../servertitle.txt");
		$serverlogo = file_get_contents("../serverlogo.txt");
		$adminqq = file_get_contents("../adminqq.txt");
		$serverdomain = file_get_contents("../serverdomain.txt");
		$servercopy = file_get_contents("../servercopy.txt");
		//$p = '/default\s([0-9]*)/';
	//preg_match($p,$info,$m);

 ?>
             <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            站点全局设置
                        </div>
                        <div class="panel-body">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>">

            <div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">流控名称/标题</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="servertitle" value="<?php echo $servertitle ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">流控全局LOGO链接</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="serverlogo" value="<?php echo $serverlogo ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">流控管理员QQ号码</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="adminqq" value="<?php echo $adminqq ?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">流控域名或IP（如有端口请带端口）</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="serverdomain" value="<?php echo $serverdomain ?>" placeholder="<?=$_SERVER['HTTP_HOST']?>">
				</div>
			</div>
			<div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">全局底部版权设置</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="servercopy" value="<?php echo $servercopy ?>">
				</div>
			</div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
			<button type="submit" class="btn btn-info btn-block">设置</button>
			</div>
	</div>
	</form> 
	</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
	}
	include('footer.php');
?>
<?php 