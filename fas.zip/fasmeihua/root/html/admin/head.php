<?php
	require('system.php');
?>
<!DOCTYPE html>
<html lang="cn">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>管理员后台管理中心 - <?php echo $servertitle ?></title>
        <!-- Common plugins -->
        <script src="/css/jquery.min.js"></script>
		<!-- <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script> -->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/bootstrap.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/simple-line-icons.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/font-awesome.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/pace.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jasny-bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/nanoscroller.css">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/metismenu.min.css">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/c3.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/blue.css" rel="stylesheet">
        <!-- dataTables -->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jquery.datatables.min.css" rel="stylesheet" type="text/css">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/responsive.bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jquery.toast.min.css" rel="stylesheet">
        <!--template css-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/style.css" rel="stylesheet">
		<link href="//img.ml.sutuo.club/css/yllmh/20171109/fasjs/jquery-ui-1.10.0.custom.css" rel="stylesheet">
    </head>
    <body>
        <div class="top-bar light-top-bar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-6">
                        <a href="index.php" class="admin-logo">
                            <h1><img src="<?php echo $serverlogo ?>" style="width:125px" alt=""></h1>
                        </a>
                        <div class="left-nav-toggle visible-xs visible-sm">
                            <a href="">
                                <i class="glyphicon glyphicon-menu-hamburger"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <ul class="list-inline top-right-nav">
                            <li class="dropdown avtar-dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php echo $adminqq ?>&s=100&t=.time()." alt="">

                                </a>
                                <ul class="dropdown-menu top-dropdown">
                                    <li><a href="javascript: void(0);"><i class="icon-user"></i> <?php echo $admin["username"]?></a></li>
									<li><a href="adminqq.php"><i class="fa fa-qq"></i> <?php echo $adminqq ?></a></li>
                                    <li><a href="user.php"><i class="icon-settings"></i> 密码修改</a></li>
                                    <li class="divider"></li>
                                    <li><a href="login.php?act=logout"><i class="icon-logout"></i> 安全退出</a></li>
                                </ul>
                            </li>

                        </ul> 
                    </div>
                </div>
            </div>
        </div>
        <nav id="right-sidebar-toggle" class="right_sidebar">
            <div class="nano">
                <div class="nano-content">
                    <div>
                        <ul class="list-inline nav-tab-panel clearfix" role="tablist">
                            <li role="presentation" class="active"><a href="#projects" aria-controls="projects" role="tab" data-toggle="tab">Projects</a></li>
                            <li role="presentation"><a href="#contacts" aria-controls="contacts" role="tab" data-toggle="tab">Contacts</a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <section class="main-content">
            <!--page header start-->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-6">
                       <!--  <h4>管理员中心</h4> -->
                    </div>
                    <div class="col-sm-6 text-right">
                        <ol class="breadcrumb">
                            <li><a href="javascript: void(0);"><i class="fa fa-home"></i></a></li>
                            <li>管理中心</li>
                        </ol>
                    </div>
                </div>
            </div><?php 