<?php

require('head.php');

require('nav.php');

function unsetLine($arr){

	foreach($arr as $v){

		if(strpos($v,"apache") === 0){

			

		}else{

			$line[] = $v;

		}

	}

	return $line;

}

//基本信息加载

$nums = db(_openvpn_)->getnums();

$user_num = db(_openvpn_)->where(["i"=>"1"])->getnums();

$nums2 = db(_openvpn_)->where(["online"=>"1"])->getnums();

$nums3 = db("auth_fwq")->where()->getnums();

$key = file_get_contents("license.key");

?>



        <!--main content start-->



            <!--page header end-->





            <!--start page content-->



            <div class="row">

                <div class="col-lg-3 col-md-6 col-sm-12">

                    <div class="widget bg-primary padding-0">

                        <div class="row row-table">

                            <div class="col-xs-4 text-center pv-15 bg-light-dark">

                                <em class="icon-users fa-3x"></em>

                            </div>

                            <div class="col-xs-8 pv-15 text-center">

                                总注册用户

								<h2 class="mv-0"><?=$nums?>&nbsp;人</h2>

                                <div class="text-uppercase">正常用户：<?=$user_num?>&nbsp;人</div>

                            </div>

                        </div>

                    </div><!--end widget-->

                </div><!--end col-->

                <div class="col-lg-3 col-md-6 col-sm-12">

                    <div class="widget bg-teal padding-0">

                        <div class="row row-table">

                            <div class="col-xs-4 text-center pv-15 bg-light-dark">

                                <em class="icon-bar-chart fa-3x"></em>

                            </div>

                            <div class="col-xs-8 pv-15 text-center">

							总在线人数

                                <h2 class="mv-0"><?=$nums2?>&nbsp;人</h2>

                                <div class="text-uppercase">活跃程度：<?= round($nums2/$nums,4)*100;?>&nbsp;%</div>

                            </div>

                        </div>

                    </div><!--end widget-->

                </div><!--end col-->

                <div class="col-lg-3 col-md-6 col-sm-12">

                    <div class="widget bg-success padding-0">

                        <div class="row row-table">

                            <div class="col-xs-4 text-center pv-15 bg-light-dark">

                                <em class="fa fa-laptop fa-3x"></em>

                            </div>

                            <div class="col-xs-8 pv-15 text-center">

							服务器数量

                                <h2 class="mv-0"><?=$nums3?>&nbsp;台</h2>

                                <div class="text-uppercase">负载总数</div>

                            </div>

                        </div>

                    </div><!--end widget-->

                </div><!--end col-->

                <div class="col-lg-3 col-md-6 col-sm-12">

                    <div class="widget bg-indigo padding-0">

                        <div class="row row-table">

                            <div class="col-xs-4 text-center pv-15 bg-light-dark">

                                <em class="icon-clock fa-3x"></em>

                            </div>

                            <div class="col-xs-8 pv-15 text-center">

							系统时间

                                <h2 class="mv-0"><?=date("H:i")?></h2>

                                <div class="text-uppercase"><?=date("Y/m/d")?></div>

                            </div>

                        </div>

                    </div><!--end widget-->

                </div><!--end col-->

            </div>

                <div class="row">

                <div class="col-md-12">

                    <div class="panel panel-default">

                            <div class="flot-chart">

                                <div class="flot-chart-content" id="line"> 加载中... </div>

                            </div>

                    </div>

                </div><!--col-md-12--><!--col-md-->

				</div>

            <div class="row">

                <div class="col-md-3 col-sm-6">

                    <div class="widget bg-primary text-center">

					    <h3 class="font-300"><span class="bwjk">Loading</span>&nbsp;Mbps/s</h3>

                        <p class="margin-b-0">    

			               网速实时监控(每分钟扫描一次)

                        </p>

                    </div><!-- end widget-->

                </div>

				<?php

		exec("top -bn1 | grep Cpu",$cpuinfo);

		//99.2 id

		preg_match('/\s*([0-9\.]*)\s*id/is',$cpuinfo[0],$cpuinfo_free);

		$lyl = 100-(float)$cpuinfo_free[1];

		  ?>

                <div class="col-md-3 col-sm-6">

                    <div class="widget bg-primary text-center">

                        <h3 class="font-300"><?=$lyl?>&nbsp;%</h3>

                        <p class="margin-b-0">

                            系统CPU利用率

                        </p>

                    </div><!-- end widget-->

                </div>

		 <?php

		 exec(" ps aux|grep jk.sh",$jiankong);

		$jiankong = unsetLine($jiankong);

		 $run = false;

		 foreach($jiankong as $v){

			// $run '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">监控运行中</span>&nbsp;<b>'.$v."</b></div>";

			 $run = true;

		 }

		 if($run){

			 echo '<div class="col-md-3 col-sm-6">';

			 echo '<div class="widget bg-success text-center">';

			 echo '<h3 class="font-300">运行正常</h3>';

			 echo '<p class="margin-b-0">用户状态扫描</p>';

			 echo '</div>';

			 echo '</div>';

		 }else{

			 echo '<div class="col-md-3 col-sm-6">';

			 echo '<div class="widget bg-danger text-center">';

			 echo '<h3 class="font-300">运行异常</h3>';

			 echo '<p class="margin-b-0">用户状态扫描</p>';

			 echo '</div>';

			 echo '</div>';

		 }

		  ?>

          <?php

		exec(" ps aux|grep FasAUTH.bin",$jiankong2);

		$jiankong2 = unsetLine($jiankong2);

		$run = false;

		foreach($jiankong2 as $v){

			//echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">监控运行中</span>&nbsp;<b>'.$v."</b></div>";

			 $run = true;

		 }

		 if($run){

			 echo '<div class="col-md-3 col-sm-6">';

			 echo '<div class="widget bg-teal text-center">';

			 echo '<h3 class="font-300">运行正常</h3>';

			 echo '<p class="margin-b-0">用户流量监控</p>';

			 echo '</div>';

			 echo '</div>';

		 }else{

		     echo '<div class="col-md-3 col-sm-6">';

			 echo '<div class="widget bg-teal text-center">';

			 echo '<a class="btn btn-danger btn-block" href="http://www.dingd.cn/doc/index.php?doc=fas#jkerror" target="_blank">';

			 echo '<h3 class="font-300">运行异常</h3>';

			 echo '</a>';

			 echo '<p class="margin-b-0">用户流量监控</p>';

			 echo '</div>';

			 echo '</div>';

		 }

		  ?>



            </div>

            <div class="row">

                <div class="col-md-6">

                    <div class="panel panel-success">

                        <div class="panel-heading">

                            TCP端口监听

                        </div>

                        <div class="panel-body">

                            *您的系统目前以对如下TCP端口进行了监听<br/>

							<?php

						 exec(" netstat -nap|grep tcp|grep \"0.0.0.0:\"",$tcp);

						$tcp = unsetLine($tcp);

						preg_match_all("/\:([0-9]*)/",implode("\n",$tcp),$m);

						foreach($m[1] as $v){ 

							echo '<span class="label label-danger">'.$v.'</span> ';

						}

						  ?>

                        </div>

                    </div>

                </div><!--col-md-6-->

                <div class="col-md-6">

                    <div class="panel panel-info">

                        <div class="panel-heading">

                            UDP端口监听

                        </div>

                        <div class="panel-body">

                            *您的系统目前以对如下UDP端口进行了监听<br/>

							<?php

							exec(" netstat -nap|grep udp|grep \"0.0.0.0:\"",$udp);

							$udp = unsetLine($udp);

							preg_match_all("/\:([0-9]*)/",implode("\n",$udp),$m);

							foreach($m[1] as $v){ 

								echo '<span class="label label-warning">'.$v.'</span> ';

							}

						  ?>

                        </div>

                    </div>

                </div><!--col-md-6-->

            </div>

            <div class="row">

<?php

		 function array_space_del($arr){

			 foreach($arr as $key=>$vo){

				 if(trim($vo) != ""){

					 $b[] = $vo;

				 }

			 }

			 return $b;

		 }

		 exec("ifconfig",$net);

		 foreach($net as $line){

			 if(trim($line)==""){

				$nets[] = $netinfo;

				$netinfo = array();

			 }else{

				$netinfo[] = $line;

			 }

		 }

		foreach($nets as $info){

			$t = explode(":",$info[0]);

			$netname = $t[0];

			

			foreach($info as $v){

				$t2 = explode(" ",$v);

				$t2 = array_space_del($t2);

				//var_dump($t2);

				switch($t2[0]){

					case $netname.":":

						$net_mtu = $t2[3];

					break;

					

					case "inet":

						$net_ip = $t2[1];

					break;

					

					case "RX":

						if($t2[1] == "packets"){

							$net_recv = $t2[4];

						}

					break;

					

					case "TX":

						if($t2[1] == "packets"){

							$net_sent = $t2[4];

						}

					break;

				}

			}

			echo '<div class="col-md-66 col-sm-6"><div class="widget bg-primary text-center">';

			echo $netname;

			echo "（MTU：";

			//echo $net_ip;

			echo $net_mtu."）<div style='margin-top:8px'>下行：";

			//echo $net_recv;

			//echo " bytes";

			$arr1 = printmb($net_recv);

			echo round($arr1['n'],1).$arr1['p']."<br/>";

			echo "上行：";

			//echo $net_sent;

			$arr2 = printmb($net_sent);

			//echo " bytes";

			echo round($arr2['n'],1).$arr2['p'];

			echo "</div></div></div>";



		}

		  ?>

<!--                 <div class="col-md-66 col-sm-6">

                    <div class="widget bg-primary text-center">

					    <h3 class="font-300">ens3</h3>(MTU:1500)

                        <p class="margin-b-0">    

			               下行：83222.4M

                        </p>

						<p class="margin-b-0">    

			               下行：83222.4M

                        </p>

                    </div>

                </div> -->

            </div>

<!--end row-->		

            <!--end page content-->

		<script src="//img.ml.sutuo.club/css/yllmh/20171109/fasjs/amcharts.js" type="text/javascript"></script>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/fasjs/serial.js" type="text/javascript"></script>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/fasjs/pie.js" type="text/javascript"></script>

<script type="text/javascript">

   

	AmCharts.ready(function () {

		$.post("rateJson.php?",{},function(json){

			var chart = new AmCharts.AmSerialChart();

			chart.dataProvider = json;

			chart.categoryField = "name";

			chart.angle = 30;

			chart.depth3D = 20;

			//标题

			chart.addTitle("15天流量趋势(单位GB)", 15);  

			var graph = new AmCharts.AmGraph();

			chart.addGraph(graph);

			graph.valueField = "value";

			//背景颜色透明度

			graph.fillAlphas = 0.3;

			//类型

			graph.type = "line";

			//圆角

			graph.bullet = "round";

			//线颜色

			graph.lineColor = "#328cc9";

			//提示信息

			graph.balloonText = "[[value]] G";

			var categoryAxis = chart.categoryAxis;

			categoryAxis.autoGridCount = false;

			categoryAxis.gridCount = json.length;

			categoryAxis.gridPosition = "start";

			chart.write("line");

		},"JSON");

        

    });

    $(function(){

		$.post("rateJson.php?act=bwi",{},function(data){

				$(".bwjk").html(data);

			});

		setTimeout(function(){

			$.post("rateJson.php?act=bwi",{},function(data){

				$(".bwjk").html(data);

			});

		}, 10000);

		

	});

</script>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>

            <!--Start footer-->

<?php

 include("footer.php");

 ?><?php 