<?php

include("head.php");
include("nav.php");
?>
<div class="row">
<div class="col-sm-12">
<div class="panel panel-default">
<div class="panel-heading">用户账户上次生成记录</div>
<div class="panel-body">
<?php
if(is_file("lastkm/userdata.php")){
	include("lastkm/userdata.php");
	$time = filemtime("lastkm/userdata.php");
	$count = count($data);
	echo "<center><h3>记录时间：".date("Y/m/d H:i:s",$time)."  共".$count."条</h3></center><hr>";
	foreach($data as $vo){
		echo "<center>用户名：".$vo["user"]."   密码：".$vo["pass"]."<br></center>";
		echo "<hr>";
	echo '<a type="button" class="btn btn-teal" style="width:100%" href="user_list.php">返回用户列表</a>';
	}
}else{
	echo "<center>您还没有生成记录哦</center>";
	echo "<hr>";
	echo '<a type="button" class="btn btn-teal" style="width:100%" href="user_list.php">返回用户列表</a>';
}
?>
</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
include("footer.php");
?>
<?php 