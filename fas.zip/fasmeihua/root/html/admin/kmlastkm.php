<?php
include("head.php");
include("nav.php");
?>
<div class="row">
<div class="col-sm-12">
<div class="panel panel-default">
<div class="panel-heading">卡密上次生成记录</div>
<div class="panel-body">
<?php
if(is_file("lastkm/kmdata.php")){
	include("lastkm/kmdata.php");
	$time = filemtime("lastkm/kmdata.php");
	$count = count($km);
	echo "<center><h3>记录时间 ".date("Y/m/d H:i:s",$time)." 共".$count."条</h3></center><hr>";
	foreach($km as $vo){
		echo '<center>'.$vo.'<br></center>';
	}
	echo "<hr>";
	echo '<a type="button" class="btn btn-teal" style="width:100%" href="km_list.php">返回卡密列表</a>';
}else{
	echo "<center>暂无卡密生成记录！</center>";
	echo "<hr>";
	echo '<a type="button" class="btn btn-teal" style="width:100%" href="km_list.php">返回卡密列表</a>';
}
?>
</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
include("footer.php");
?><?php 