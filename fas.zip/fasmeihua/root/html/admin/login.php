<?php
$display_login = true;
function getClientIP()  
{  
    global $ip;  
    if (getenv("HTTP_CLIENT_IP"))  
        $ip = getenv("HTTP_CLIENT_IP");  
    else if(getenv("HTTP_X_FORWARDED_FOR"))  
        $ip = getenv("HTTP_X_FORWARDED_FOR");  
    else if(getenv("REMOTE_ADDR"))  
        $ip = getenv("REMOTE_ADDR");  
    else $ip = "Unknow";  
    return $ip;  
}  
$cip = getClientIP();
if($_GET["act"] == "do_login"){
	require("system.php");
	$last_ip_file = R."/cache/last_ip.log";
	if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	if(trim($u) == "" || trim($p) == ""){
		die(json_encode(["status"=>"error","msg"=>"信息不完整"]));
	}else{
		$last_ip = file_get_contents($last_ip_file);
		if($cip != $last_ip){
			$auth_key = trim($_POST["auth_key"]);
			$local_key = file_get_contents("/var/www/auth_key.access");
			if($auth_key == "" || $auth_key != trim($local_key)){
				die(json_encode(["status"=>"error","msg"=>"口令错误"]));
			}
		}
		$admin = db("app_admin")->where(array("username"=>$u,"password"=>$p))->find();
		if($admin){
			$_SESSION["dd"]["username"] = $u;
			$_SESSION["dd"]["password"] = $p;
			file_put_contents($last_ip_file,$cip);
			die(json_encode(["status"=>"success","msg"=>""]));
		}else{
			die(json_encode(["status"=>"error","msg"=>"密码错误"]));
		}
	}
}
}elseif($_GET["act"] == "logout"){
	require("system.php");
	unset($_SESSION["dd"]);
	header("location:admin.php");
}else{
$title="后台登陆";
require("heads.php");
$last_ip_file = R."/cache/last_ip.log";
$last_ip = file_get_contents($last_ip_file);
$serverlogo = file_get_contents("../serverlogo.txt");
$servertitle = file_get_contents("../servertitle.txt");
$serverdomain = file_get_contents("../serverdomain.txt");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>管理员后台登录 - <?php echo $servertitle ?></title>

        <!-- Common plugins -->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/bootstrap.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/simple-line-icons.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/font-awesome.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/pace.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jasny-bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/nanoscroller.css">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/metismenu.min.css">
        <!--for checkbox-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/blue.css" rel="stylesheet">
        <!--template css-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/html5shiv.min.js"></script>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/respond.min.js">049cdb</script>
        <![endif]-->
        <style type="text/css">
            html,body{
                height: 100%;
            }
        </style>
    </head>
    <body>

        <div class="misc-wrapper">
            <div class="misc-content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                            <div class="misc-header text-center">
                                <img src="<?php echo $serverlogo ?>" style="width:125px" alt="">
                            </div>
                            <div class="misc-box">   
                                <p class="text-center text-uppercase pad-v">管理员后台登录</p>
                                <form action="./admin.php">
                                    <div class="form-group">                                      
                                        <label class="text-muted" for="exampleuser1">管理员帐号</label>
                                        <div class="group-icon">
                                        <input name="user" id="exampleuser1" type="text" placeholder="username" class="form-control input-lg">
                                        <span class="icon-user text-muted icon-input"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="text-muted" for="exampleInputPassword1">管理员密码</label>
                                        <div class="group-icon">
                                        <input name="pass" id="inputPassword" type="password" placeholder="password" class="form-control input-lg">
                                        <span class="icon-lock text-muted icon-input"></span>
                                        </div>
                                    </div>
									<?php if($cip != $last_ip){ ?>
                                    <div class="form-group">
                                        <label class="text-muted" for="exampleInputPassword1">管理员口令</label>
                                        <div class="group-icon">
                                        <input name="auth_key" id="inputPassword" type="password" placeholder="位于/var/www/auth_key.access里的口令" class="form-control input-lg">
                                        <span class="icon-lock text-muted icon-input"></span>
                                        </div>
                                    </div>
		<p>
		<button type="button" class="btn btn-block btn-default" style="width:100%" onclick="javascript:$('.dbkl').toggle()">什么是本地口令？</button>
		<div class="dbkl" style="display:none;color:#222;font-size:14px;">
		<div class="alert alert-info alert-dismissible fade in" role="alert">
			本地口令，是一种不存储在数据库的本地密码。存储在<b>/var/www/auth_key.access</b>,修改文件内容本地口令也会随之更改。首次登录以及登录IP与上次不同时，会要求您输入!其目的是为了防止当数据库泄露或者密码被爆破黑客可以轻松入侵您的后台！因为本地口令不存在于数据库，所以不会被黑客截取！所以，我们强烈建议您，将本地口令与登录密码设置为不同的密码。<br>
			您可以随时通过以下方式查看：<br>
			命令行:<b>cat /var/www/auth_key.access</b><br>
			或者直接登录sftp或者ftp查看!
		</div>
		</div>
		</p>
									<?php } ?>
                                    <div class="clearfix">
                                            <button type="submit" style="width:100%" class="btn btn-primary do_login">登录</button>
                                    </div>
                                    <hr>
                                    <a href="../user/" class="btn btn-success" style="width:100%">前往用户中心</a>
									<p></p>
									<a href="../daili/" class="btn btn-warning" style="width:100%">前往代理中心</a>
									</hr>
                            </div>
                            <div class="text-center misc-footer">
<?php echo $servercopy ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Common plugins-->
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/pace.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jasny-bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.slimscroll.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.nanoscroller.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/metismenu.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/float-custom.js"></script>
        <!--ichecks-->
	<script>
	$(function(){
		$(".do_login").click(function(){
			var username = $("[name='user']").val();
			var password = $("[name='pass']").val();
			var auth_key = $("[name='auth_key']").val();
			if(username == "" || password == ""){
				alert("信息不完整");
			}else{
				$.post("?act=do_login",
				{
					"user":username,
					"pass":password,
					"auth_key":auth_key
				},function(data){
					if(data.status == "success"){
						window.location.href="admin.php";
					}else{
						alert(data.msg);
					}
				},"JSON");
			}
		});
	});
	</script>
    </body>
</html>
<?php 
}
?><?php 