<?php

function getkm($len = 18)
{
	$str = "0123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}

if($_GET['act'] == 'save'){
	include('system.php');
	$db = db("app_kms");
	$n = 0;
	for($i=0;$i<intval($_POST["nums"]);$i++){
		$km = getkm(18);
		if($db->insert(array("km"=>$km,"addtime"=>time(),"type_id"=>$_POST["tid"]))){
			$kms[] = '$km[]="'.$km."\";";
			$n++;
		};
	}
	file_put_contents("lastkm/kmdata.php",'<?php'."\n".implode("\n",$kms));
	die(json_encode(array("status"=>'success')));

}elseif($_GET['act'] == 'del'){
	include('system.php');
	$db = db('app_kms');
	if($db->where(array('id'=>$_POST['id'],"daili"=>0))->delete()){
		die(json_encode(array("status"=>'success')));
	}else{
		die(json_encode(array("status"=>'error')));
	}
}elseif($_GET['act'] == 'del_select'){
	include('head.php');
	include('nav.php');
	$db = db('app_kms');
	$n = 0;
	$arr = $_POST['checkbox'];
	foreach($arr as $id){
		if($db->where(array('id'=>$id,"daili"=>0))->delete()){
			$n++;
		}
	}
	
	tip_success($n."条卡密删除成功","?tid=".$_GET["id"]);
	
}elseif($_GET['act'] == 'search'){
	include('head.php');
	include('nav.php');
	$rs = db("app_kms")->where(["km"=>$_GET["kw"]])->order("id DESC")->select();
	if($rs){
		echo '<table class="table table-striped">
	   <thead>
		  <tr>
		   <th style="width:50px;"><input name="checkbox-all" type="checkbox" value="" /></th>
		   <th>ID</th>
	   <th>卡密</th>
	   <th>状态</th>
		<th>套餐时间</th>
		<th>套餐流量</th>
		<th>使用者</th>
		<th>使用时间</th>
		<th>添加时间</th>
		<th>操作</th>
		  </tr>
	   <tbody>';
		foreach($rs as $res){
			$info = db("app_tc")->where(array("id"=>$res["type_id"]))->find();
			echo "<tr class=\"line-id-".$res["id"]."\">";
			echo "<td><input name=\"checkbox[]\" type=\"checkbox\" value=\"".$res["id"]."\" /></td>";
			echo "<td>".$res["id"]."</td>";
			echo "<td style=\"width:200px\">";
				if($res["isuse"] == 1){
					echo '<s style="color:red">'.$res["km"].'</s>';
				}else{
					echo $res["km"];
				}
			
			"</td>";
			echo "<td>";
			if($res["isuse"] == 1){
				echo "已使用";
			}else{
				echo "正常";
			}
			echo "</td>";
			echo "<td>".$info["limit"]."天</td>";
			echo "<td>".round($info["rate"],3)."MB&nbsp;".$pre."</td>";
			echo "<td>";
			if($res["user_id"]>0){
				$uinfo = db(_openvpn_)->where(["id"=>$res["user_id"]])->find();
				echo $uinfo["iuser"];
			}else{
				echo " - ";
			}
			echo "</td>";
			echo "<td>";
			if($res["usetime"]!=""&&$res["usetime"]!=0){
				echo date("Y/m/d H:i:s",$res["usetime"]);
			}else{
				echo " - ";
			}
			echo "</td>";
			echo "<td>";
			if($res["addtime"]!=""&&$res["addtime"]!=0){
				echo date("Y/m/d H:i:s",$res["addtime"]);
			}else{
				echo " - ";
			}
			echo "</td>";
			echo '<td><button type="button" class="btn btn-danger btn-xs" onclick="delById(\''.$res["id"].'\')">删除</button></td>';
			echo "</tr>";
		}
		echo "
			 </tbody>
		   </thead>
		</table>";
	}else{
		echo "<center>";
		echo "该套餐下暂无任何卡密！";
		echo "</center>";
	}
	?>
	<script>
   $(function(){
	   $('#myModal').modal('hide');
	   });
	 
	function delById(id,action){
		if(confirm('确认删除吗？删除后不可恢复哦！')){
			var url = "?act=del";
			var data = {
				"id":id
			};
			$.post(url,data,function(data){
				if(data.status == "success"){
					$('.line-id-'+id).slideUp();
				}else{
					alert("删除失败");
				}
			},"JSON");
		}
	}

	function delAll(id){
		if(confirm('确认删除吗？删除后不可恢复哦！')){
			location.href="?act=del_all&gid="+id;
		}
	}
   $(function () { $('#myModal').on('hide.bs.modal', function () {
      //alert('嘿，我听说您喜欢模态框...');
	  })
   });
   $(function(){
	   
	   $(".save").click(function(){
		   var nums = $("#creat_kms").val();
		   if(nums == ""){
			   alert("请输入生成的卡密数量");
		   } 
		   $.post('?act=save',{
			   "tid":'<?php echo $tid?>',
			   "nums":nums
			},function(data){
				if(data.status == "success"){
					 $('#setting').click();
					 window.location.href="lastkm/index.php";
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
   });
</script>
	<?php
	include("footer.php");
}elseif($_GET['act'] == 'show'){
	include('head.php');
	echo "请复制保存<br>";
	$db = db('app_kms');
	$list = $db->where(array('type_id'=>$_GET['id'],"isuse"=>0,"daili"=>0))->order("id DESC")->select();
	echo "<br><textarea style='width:100%;height:400px;'>";
	foreach($list as $vo){
		echo $vo["km"]."\n";
	}
	echo "</textarea>";
}elseif($_GET['act'] == 'del_all'){
	include('head.php');
	include('nav.php');
	$db = db('app_kms');
	if($db->where(array('type_id'=>$_GET['gid'],"daili"=>0))->delete()){
		tip_success("删除成功",$_SERVER['HTTP_REFERER']);
	}else{
		tip_failed("删除失败",$_SERVER['HTTP_REFERER']);
	}
}else{
$title='卡密生成';
include('head.php');
include('nav.php');
if(trim($_GET["tid"]) == ""){
	$tmp = db("app_tc")->order("id DESC")->find();
	$tid =  $tmp["id"];
}else{
	$tid = $_GET["tid"];
}
if(!$tc_info = db("app_tc")->where(array("id"=>$tid))->find()){
	die("没有此套餐");
};
?>
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            卡密管理/生成
                        </div>
                        <div class="panel-body">
  <div class="col-sm-12">
  <form action="?" method="get" class="form-inline">
		<input type="hidden" class="form-control" style="width:100%" name="act" value="search">
		<input type="text" class="form-control" style="width:100%" name="kw" placeholder="卡密">
	   	<button type="submit" class="btn btn-primary" style="width:100%">搜索</button>
  </form>
	</div>
<div style="clear:both;height:20px;"></div>
<form action="?act=del_select" method="POST">
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<button type="submit" class="btn btn-danger" style="width:100%">删除所选</button>
</center>
</div>
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<button type="button" class="btn btn-danger" style="width:100%" onclick="delAll('<?php echo $tid?>')">清空本套餐</button>
</center>
</div>
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<a type="button" class="btn btn-teal" style="width:100%" href="km_list.php?act=show&id=<?php echo $tid?>" target="_blank">导出本套餐未使用卡密</a>
</center>
</div>
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<a class="btn btn-success" style="width:100%" data-toggle="modal" data-target="#myModal" id="setting">
	新增卡密
</a>
</center>
</div>
<div style="clear:both;height:20px;"></div>
<div class="col-sm-12">
<center>
<button type="button" class="btn btn-primary btn-xs">套餐</button>
<?php

//$rs=$DB->query("SELECT * FROM `auth_fwq`  order by id desc limit 20");
$km_type = db("app_tc")->order("id DESC")->select();
foreach($km_type as $res)
{
	if($res['id'] == $tid){
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<a href="?tid='.$res['id'].'" class="btn btn-primary btn-xs">'.$res['name'].'</a>';
	}else{
		echo '&nbsp;&nbsp;&nbsp;&nbsp;<span><a href="?tid='.$res['id'].'">'.$res['name'].'</a></span>';
	}
}
?>
</center>
<div style="clear:both;height:15px;"></div>
<div class="table-responsive">
<?php 
$numrows = db("app_kms")->where(array("type_id"=>$tid,"daili"=>0))->order("id DESC")->getnums();
$rs = db("app_kms")->where(array("type_id"=>$tid,"daili"=>0))->order("id DESC")->fpage($_GET["page"],30)->select();
if($rs){
	echo '<table class="table table-striped">
   <thead>
    <tr>
	<th style="width:50px;"><input name="checkbox-all" type="checkbox" value="" /></th>
	<th><center>ID</center></th>
    <th><center>卡密</center></th>
    <th><center>状态</center></th>
    <th><center>套餐时间</center></th>
	<th><center>套餐流量</center></th>
	<th><center>使用者</center></th>
	<th><center>使用时间</center></th>
	<th><center>添加时间</center></th>
	<th><center>操作</center></th>
    </tr>
   <tbody>';
	foreach($rs as $res){
		$info = db("app_tc")->where(array("id"=>$res["type_id"]))->find();
		echo "<tr class=\"line-id-".$res["id"]."\">";
		echo "<td><input name=\"checkbox[]\" type=\"checkbox\" value=\"".$res["id"]."\" /></td>";
		echo "<td><center>".$res["id"]."</center></td>";
		echo "<td style=\"width:200px\"><center>";
			if($res["isuse"] == 1){
				echo '<s style="color:red">'.$res["km"].'</s>';
			}else{
				echo $res["km"];
			}
		
		"</center></td>";
		echo "<td><center>";
		if($res["isuse"] == 1){
			echo "已使用";
		}else{
			echo "正常";
		}
		echo "</center></td>";
		echo "<td><center>".$info["limit"]."天</center></td>";
		echo "<td><center>".round($info["rate"],3)."MB&nbsp;".$pre."</center></td>";
		echo "<td><center>";
		if($res["user_id"]>0){
			$uinfo = db(_openvpn_)->where(["id"=>$res["user_id"]])->find();
			echo $uinfo["iuser"];
		}else{
			echo " - ";
		}
		echo "</center></td>";
		echo "<td><center>";
		if($res["usetime"]!=""&&$res["usetime"]!=0){
			echo date("Y/m/d H:i:s",$res["usetime"]);
		}else{
			echo " - ";
		}
		echo "</center></td>";
		echo "<td><center>";
		if($res["addtime"]!=""&&$res["addtime"]!=0){
			echo date("Y/m/d H:i:s",$res["addtime"]);
		}else{
			echo " - ";
		}
		echo "</center></td>";
		echo '<td><center><button type="button" class="btn btn-danger btn-xs" onclick="delById(\''.$res["id"].'\')">删除</button></center></td>';
		echo "</tr>";
	}
	echo "
		 </tbody>
	   </thead>
	</table>";
}else{
	echo "<center>";
	echo "该套餐下暂无任何卡密！";
	echo "</center>";
}
?>
</form>
</div>
</div>
</div>
</div>
</div>
<?php
echo '<div class="col-sm-12 text-right">';
echo create_page_html($numrows,$_GET["page"],30,"&tid=".$_GET["tid"]);
echo '</div>';
#分页
?>
</div>
	<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
				</button>
				<h4 class="modal-title" id="myModalLabel">
					卡密生成
				</h4>
			</div>
			<div class="modal-body">
				
				 <div class="form-group">
					<label for="name">生成的套餐：</label>
					<?php 
						echo $tc_info["name"].'(';
						echo $tc_info["limit"]."天/".round($tc_info["rate"],3)."M)";
					?>
				  </div>
				  <div class="form-group">
					<label for="name">请输入数量(0-9999)</label>
				<input type="text" class="form-control" id="creat_kms" placeholder=""  value="1">
					
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
					关闭
				</button>
				<button type="button" class="btn btn-primary save">
					提交更改
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<script>
   $(function(){
	   $('#myModal').modal('hide');
	   });
	 
	function delById(id,action){
		if(confirm('确认删除吗？删除后不可恢复哦！')){
			var url = "?act=del";
			var data = {
				"id":id
			};
			$.post(url,data,function(data){
				if(data.status == "success"){
					$('.line-id-'+id).slideUp();
				}else{
					alert("删除失败");
				}
			},"JSON");
		}
	}

	function delAll(id){
		if(confirm('确认删除吗？删除后不可恢复哦！')){
			location.href="?act=del_all&gid="+id;
		}
	}
   $(function () { $('#myModal').on('hide.bs.modal', function () {
      //alert('嘿，我听说您喜欢模态框...');
	  })
   });
   $(function(){
	   
	   $(".save").click(function(){
		   var nums = $("#creat_kms").val();
		   if(nums == ""){
			   alert("请输入生成的卡密数量");
		   } 
		   $.post('?act=save',{
			   "tid":'<?php echo $tid?>',
			   "nums":nums
			},function(data){
				if(data.status == "success"){
					 $('#setting').click();
					 window.location.href="kmlastkm.php";
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
   });
</script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php 
}
	include("footer.php");
?>
 