<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
if($_GET["a"] == "qset"){
	include("qset.php");
	}else{

?>
               <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            用户列表
                        </div>
                        <div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="panel panel-default">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
$user=$_GET['user'];
$sql=db(_openvpn_)->where(array(_iuser_=>$user))->delete();
if($sql){
	db("top")->where(["username"=>$user])->delete();
	echo '删除成功！';
	}
else{
	echo '删除失败！';
}
echo '<hr/><a href="./user_list.php">>>返回账号列表</a></div></div>';
}

else
{
echo '<form action="user_list.php" method="get" class="form-inline">
  <div class="col-sm-12">
    <input type="text" class="form-control" style="width:100%" name="kw" placeholder="支持模糊搜索" value="'.$_GET["kw"].'">
  <button type="submit" class="btn btn-primary" style="width:100%">搜索</button>&nbsp;
  </div>';
if(!empty($_GET['kw'])) {
	$numrows = db(_openvpn_)->where(_iuser_." LIKE :kw",[":kw"=>"%".$_GET["kw"]."%"])->getnums();
	$where = _iuser_." LIKE :kw";
	$data = [":kw"=>"%".$_GET["kw"]."%"];
	$con='
	<div class="col-lg-3 col-md-6 col-sm-12">
	<center>
	<a href="#" class="btn btn-success" style="width:100%">平台共有 <b>'.$numrows.'</b> 个账号</a>
	</center>
	</div>';
}else{
	//$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
	$numrows = db(_openvpn_)->where()->getnums();
	$where= '';
	$con='
	<div class="col-lg-3 col-md-6 col-sm-12">
	<center>
	<a href="#" class="btn btn-success" style="width:100%">平台共有 <b>'.$numrows.'</b> 个账号</a>
	</center>
	</div>';
	
}
echo $con;
echo '
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<button type="button" class="btn btn-danger" style="width:100%" onclick="if(!confirm(\'清理全部禁用用户？执行后不可恢复！\')){return false;}else{delAllJ()}">清理全部禁用用户</button>
</center>
</div>';
echo '
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<button type="button" class="btn btn-indigo" style="width:100%" onclick="javascript:var n = prompt(\'统一新增流量，减少请输入负数（单位：G）\');if(!n){return false;}else{addLlAll(n)}">统一新增流量</button>
</center>
</div>';
echo '
<div class="col-lg-3 col-md-6 col-sm-12">
<center>
<button type="button" class="btn btn-teal" style="width:100%" onclick="javascript:var n = prompt(\'统一新增天数，减少请输入负数（单位：天）\');if(!n){return false;}else{addTimeAll(n)}">统一新增天数</button>
</center>
</div>';
echo '</form>';

?>
<div style="clear:both;height:20px;"></div>
   <div class="col-sm-12">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
		  <tr>
		  <th width="50"><center>序号</center></th>
		  <th><center>账号</center></th>
		  <th><center>添加时间</center></th>
		  <th><center>到期时间</center></th>
		  <th><center>剩余流量</center></th>
		  <th><center>总流量</center></th>
		  <th><center>状态</center></th>
		  <th><center>操作</center></th>
		  </tr>
		  </thead>
          <tbody>
<?php
$rs = db(_openvpn_)->where($where,$data)->fpage($_GET["page"],30)->order("id DESC")->select();
$i = 1;
foreach($rs as $res)
{ 
if(date("Y-m-d",$res['starttime']) == date("Y-m-d",time())){
	$p = '&nbsp;<span class="label label-success">今日新增</span>';
}elseif(date("Y-m-d",$res['starttime']) == date("Y-m-d",(time()-24*60*60))){
	$p = '&nbsp;<span class="label label-warning">昨日新增</span>';
}else{
	$p ="";
}

if($res["vip"] == 1){
	$vip = '&nbsp;<span class="label label-success">VIP</span>';
}elseif($res["vip"] == 2){
	$vip = '&nbsp;<span class="label label-warning">VIP2</span>';
}else{
	$vip ="";
}
?>
<tr class="line-id-<?=$res['iuser']?>">
<td><center><?=$res['id']?></center></td>
<td><center><?=$vip?><?=$res['iuser']?><?=$p?></center></td>
<td><center><?=date("Y-m-d",$res['starttime'])?></center></td>
<td><center><?=date("Y-m-d",$res['endtime'])?></center></td>
<td><center><span class="shengyu"><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?></span>MB</center></td>
<td><center><span class="maxll"><?=round(($res['maxll'])/1024/1024)?></span>MB</center></td>
<td><center><?=($res['i']?'开通':'禁用')?></center></td>
<td><center><a class="btn btn-default" href="./user_list.php?a=qset&user=<?=$res['iuser']?>">配置</a>&nbsp;<a href="javascript:void(0)" class="btn btn-primary" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}else{delLine('<?=$res['iuser']?>')}">删除</a>&nbsp;<a href="javascript:void(0)" class="btn btn-primary"   onclick="javascript:var n = prompt('请输入您要重置的流量（单位：G)');if(!n){return false;}else{addLl('<?=$res['id']?>',n)}">新增</a></center></td>
</tr>

<?php 
	$i++;
}
?>
          </tbody>
        </table>
    </div>

<?php
echo '<div class="col-sm-12 text-right">';
echo create_page_html($numrows,$_GET["page"]);
echo '</div>';
}
?>
 </div>  
 </div>
 </div>
</div>
</div>
<script>
function addLlAll(n){
		var url = './option.php?my=addllAll';
		$.post(url,{
			"n":n
		  },function(){
			
		});
		//var m = $('.line-id-'+id+" .maxll");
		//var ne = n*1024;
		//m.html(ne);
		location.reload();
}

function addTimeAll(n){
		var url = './option.php?my=addtimeAll';
		$.post(url,{
			"n":n
		  },function(){
			
		});
	
		location.reload();
}

function addLl(id,n){
		var url = './option.php?my=addll';
		$.post(url,{
			"n":n,
			"user":id
		  },function(){
			location.reload();
		});
}
function delAllJ(){
		var url = './option.php?my=deljy';
		$.post(url,{
		  },function(){
			location.reload();
		});
}
</script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
	} 
include("footer.php");
?>
<?php 