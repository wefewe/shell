<?php
	include('head.php');
	include('nav.php');
	$m = new Map();
 	if($_GET['act'] == 'update'){
		

		$dailigg = file_put_contents("../dailigg.txt",$_POST["dailigg"]);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$dailigg = file_get_contents("../dailigg.txt");
		//$p = '/default\s([0-9]*)/';
	//preg_match($p,$info,$m);

 ?>
             <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            代理中心公告调用API设置
                        </div>
                        <div class="panel-body">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>">

            <div class="form-group">
				<label for="firstname" class="col-sm-2 control-label">代理中心首页动态公告调用API</label>
				<div class="col-sm-10">
				<input class="form-control" rows="10" name="dailigg" value="<?php echo $dailigg ?>">
				</div>
			</div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
			<button type="submit" class="btn btn-info btn-block">设置</button>
			</div>
	</div>
	</form> 
	</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
	}
	include('footer.php');
?>
<?php 