<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
?>
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            代理级别列表
                        </div>
                        <div class="panel-body">
<?php

if($_GET["act"]=='del'){
	if(db("app_daili_type")->where(array("id"=>$_GET['id']))->delete()){
		tip_success("操作成功！",$_SERVER['HTTP_REFERER']);
	}else{
		tip_failed("十分抱歉修改失败",$_SERVER['HTTP_REFERER']);
	}
}else{

	$rs=db("app_daili_type")->where()->order("id DESC")->select();
	$i = 1;
	if($rs){
	foreach($rs as $res)
	{ 
	
		echo ' <li class="list-group-item">
        <B>级别：</B>'.$res["name"].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>折扣率：</B>'.$res["per"].'%
		<div align="right">
		<a type="submit" href="type_add.php?act=mod&id='.$res["id"].'" class="btn btn-success">编辑</a>';
		echo '<a type="submit" class="btn btn-danger" href="?act=del&id='.$res["id"].'" onclick="if(confirm(\'确认删除？\')){return true}else{return false;}">删除</a>
		</div>
    </li>';
	}
	}else{
		echo '<div class="box">暂无数据</div>';
	}
}
?>
</div>
</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
include("footer.php");
?>
<?php 