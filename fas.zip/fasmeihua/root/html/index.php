<?php
require('system.php');
$lock = R.'/qqzd.qqzdlock';
if(!is_file($qqzdlock))
{
	$db = db();
	$db->exec('alter table `openvpn` ADD `qq` text NOT NULL');
	
	echo '[ success ]';
	file_put_contents('qqzd.qqzdlock',' ');
}
	// @unlink(R.'/qqzd.php');
	 header("location:user/");