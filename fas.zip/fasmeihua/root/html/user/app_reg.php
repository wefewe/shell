<?php

	//上次短信发送时间
	$system_time = time();
	$last_time = $_SESSION["last_send"] == "" ? 0 : $_SESSION["last_send"];
	$al_time = $system_time - $last_time;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>新用户注册 - <?php echo $servertitle ?></title>

        <!-- Common plugins -->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/bootstrap.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/simple-line-icons.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/font-awesome.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/pace.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jasny-bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/nanoscroller.css">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/metismenu.min.css">
        <!--for checkbox-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/blue.css" rel="stylesheet">
        <!--template css-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/style.css" rel="stylesheet">
		<link href="//img.ml.sutuo.club/css/yllmh/20171109/css/sweet-alert.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/html5shiv.min.js"></script>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/respond.min.js"></script>
        <![endif]-->
        <style type="text/css">
            html,body{
                height: 100%;
            }
        </style>
    </head>
    <body>

        <div class="misc-wrapper">
            <div class="misc-content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                            <div class="misc-header text-center">
                                <img src="<?php echo $serverlogo ?>" style="width:125px" alt="">
                            </div>
                            <div class="misc-box">   
                                <p class="text-center text-uppercase pad-v">新用户注册</p>

                                    <div class="form-group">                                      
                                        <label class="text-muted" for="name">用户名</label>
                                        <div class="group-icon">
                                        <input id="name" type="text" placeholder="一般使用手机号或QQ号码" class="form-control">
                                        <span class="icon-user text-muted icon-input"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="text-muted" for="pass">密码</label>
                                        <div class="group-icon">
                                        <input id="pass" type="password" placeholder="密码" class="form-control">
                                        <span class="icon-lock text-muted icon-input"></span>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <label class="text-muted" for="pass2">确认密码</label>
                                        <div class="group-icon">
                                        <input id="pass2" type="password" placeholder="再次输入密码" class="form-control">
                                        <span class="icon-lock text-muted icon-input"></span>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <label class="text-muted" for="qq">QQ号码</label>
                                        <div class="group-icon">
                                        <input id="qq" name="qq" type="text" placeholder="请输入您的QQ号码" class="form-control">
                                        <span class="fa fa-qq text-muted icon-input"></span>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <label class="text-muted" for="code">验证码</label>
                                        <div class="group-icon">
                                        <input id="code" type="text" placeholder="填写验证码" class="form-control" style="float:left;width:60%"> 
                                        <img src="/app_api/mode/check_code.php?t=<?php echo time()?>" height="34" width="100" class="ccode" onclick='$(".ccode").attr({"src":"/app_api/mode/check_code.php?t="+Date.parse(new Date())});' style="float:right;width:35%">
                                        </div>
                                    </div>
                                    <!-- <div class="clearfix"> -->
                                        <!-- <center> -->
										<!-- <img src="/app_api/mode/check_code.php?t=<?php echo time()?>" class="ccode" onclick='$(".ccode").attr({"src":"/app_api/mode/check_code.php?t="+Date.parse(new Date())});'> -->
										<!-- </center> -->
<!-- <br/> -->
                                    <!-- </div> -->
                                            <button type="submit" class="btn btn-primary" style="width:100%" onclick="reg()">免费注册</button>

                                    <hr>
                                    <a href="login.php" class="btn btn-success" style="width:100%">已有帐号，登录</a>
									<p></p>
									<a href="../daili/" class="btn btn-warning" style="width:100%">前往代理中心</a>
									<hr>
                            </div>
                            <div class="text-center misc-footer">
<?php echo $servercopy ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>


function reg(){
	if($("#name").val() == ""|| $("#pass").val() == "" || $("#qq").val() == "" || $("#code").val() == ""){
		alert("任何一项均不能为空");
	}else if($("#name").val() == ""){
		alert("用户名不得为空哦");
		return;
	}else if($("#pass").val() != $("#pass2").val()){
		alert("两次密码不一致");
		return;
	}else{
		$.post(
			'reg.php?act=reg_in',{
				"username":$("#name").val(),
				"password":$("#pass").val(),
				"qq":$("#qq").val(),
				"code":$("#code").val()
			},function(data){
				if(data.status == "success"){
                    swal({
                        title: "注册成功",
                        text: "欢迎使用速拓云流量，现可以前往会员中心登录管理！",
                        type: "success",
                        showCancelButton: true,
                        cancelButtonClass: 'btn-secondary ',
                        confirmButtonClass: 'btn-success  ',
                        confirmButtonText: '确定',
						closeOnConfirm: false
                    }, function () {
                        window.location.href="login.php";
                    });
				}else{
					$(".ccode").attr({"src":"/app_api/mode/check_code.php?t="+Date.parse(new Date())});
					alert(data.msg);
				}
			},"JSON"
		)
	}
}
function sysC(){
	window.myObj.colsePage();
}
$(function() { 
        $('#myModal').modal({ 
            keyboard: true 
        }) 
    }); 
</script>

        <!--Common plugins-->
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/pace.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jasny-bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.slimscroll.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.nanoscroller.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/metismenu.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/float-custom.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/sweet-alert.min.js"></script>
        <!--ichecks-->
    </body>
</html>
<?php 