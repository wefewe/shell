<?php
include("api_head.php");
include("nav.php");
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("app_kms")->where(array("km"=>$km))->find();
	if(!$myrow){
		echo "<script>alert('此激活码不存在');</script>";
	}elseif($myrow['isuse']==1){
		echo "<script>alert('此激活码已被使用');</script>";
	}else{
		$type_id = $myrow["type_id"];
		$tc = db("app_tc")->where(array("id"=>$type_id))->find();
		if(!$tc){
			echo "<script>alert('套餐已经失效');</script>";
		}
		//$uinfo = db(_openvpn_)->where(array(_iuser_=>$userinfo[""]))->find();
		$duetime = time() + $tc['limit']*24*60*60;
		$addll = $tc['rate']*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["daili"] = $myrow["daili"];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(["id"=>$userinfo["id"]])->update($update)){
			db("app_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user_id"=>$userinfo["id"],"usetime"=>time()));
			echo "<script>alert('开通成功');</script>";
		}else{
			echo "<script>alert('开通失败');</script>";
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?>

<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            IOS使用教程
                        </div>
                        <div class="panel-body">

                                <div class="col-sm-12">
								<center>
<h3 class="text-danger">注意事项：</h3>
苹果手机openvpn默认设置会在待机的时候自动掉线。请按照以下设置进行设置，待机就不会掉线了！<br>
设置步骤：手机设置---往下拉到底找到“openvpn”点进去---将第二个选项按钮打开（“Seamless tunnel（iOS8+）”按钮打开）
<br><br>
<h3 class="text-danger">①：进入“手机设置”，登陆国外APPLEID帐号</h3>
<h5>登陆ID：eb0051@163.com</h5><h5>登陆密码：Yy336699</h5><h5>注：本APPLEID仅用于商店的登录，请勿登录iCloud，使用完成后请立即退出帐号</h5><br>
<img style="border: 2px solid #1281FF;" src="https://img.ml.sutuo.club/iosinfo/ios_1.jpg" width="100%"/>
<br />
<h3 class="text-danger"><br>②：搜索“openvpn”软件并安装</h3>
<h5>如出现无法搜索空白页面，请稍作等待；</h5>
<h5>该软件无法下载或者遇到问题，请联系在线客服</h5><br>
<img style="border: 2px solid #1281FF;" src="https://img.ml.sutuo.club/iosinfo/ios_2.jpg" width="100%"/>
<br />
<h3 class="text-danger"><br>③：加载苹果ios版线路配置文件</h3>
<h5><a class="btn m-b-xs btn-primary btn-rounded" href="iosline.php?act=line&key=&username=&password=&location=true">点此安装苹果ios版线路</a></h5><br>
<img style="border: 2px solid #1281FF;" src="https://img.ml.sutuo.club/iosinfo/ios_3.jpg" width="100%"/>
<br />
<h3 class="text-danger"><br>④：输入帐号密码进行连接</h3><br>
<img style="border: 2px solid #1281FF;" src="https://img.ml.sutuo.club/iosinfo/ios_4.jpg" width="100%"/>
<br><br><br>
<h2 style="color:#F66;">免流首次使用测试说明</h2>
<h4>由于全国地区众多，不一定所有地区都能免流量成功，因此第一次使用前请按以下方法进行测试</h4>
<h4>①：免流连接后查询运营商流量（推荐掌上营业厅或短信查询）</h4>
<h4>②：下载一个10M左右的文件或APP等均可</h4>
<h4>③：下载完成后，等待10分钟左右再次查询运营商流量（期间若有待机，请注意设置待机防掉线设置）</h4>
<h4>④：对比前后两次查询的运营商流量</h4>
<h4>说明：如果套餐内的流量没扣或扣的很少则说明可以正常使用免流，否则为不免！</h4>
<h4 style="color:#F66;">注：部分机型使用过程中出现网速慢，突然不免的请开关手机飞行模式。</h4><br>
                        </center>
								</div>
								</div>
								</div>
								</div>
								</div>

        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
            <!--Start footer-->
<?php
 include("api_footer.php");
 ?>