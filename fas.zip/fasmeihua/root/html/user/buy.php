<?php
include("api_head.php");
include("nav.php");
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("app_kms")->where(array("km"=>$km))->find();
	if(!$myrow){
		echo "<script>alert('充值卡密不存在，请重新输入');</script>";
	}elseif($myrow['isuse']==1){
		echo "<script>alert('该卡密已被使用，请重新输入');</script>";
	}else{
		$type_id = $myrow["type_id"];
		$tc = db("app_tc")->where(array("id"=>$type_id))->find();
		if(!$tc){
			echo "<script>alert('该卡密已失效，请联系在线客服');</script>";
		}
		//$uinfo = db(_openvpn_)->where(array(_iuser_=>$userinfo[""]))->find();
		$duetime = ($userinfo['endtime'] < time() ? time() : $userinfo['endtime']) + $tc['limit']*24*60*60;
		$addll = $tc['rate']*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["daili"] = $myrow["daili"];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(["id"=>$userinfo["id"]])->update($update)){
			db("app_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user_id"=>$userinfo["id"],"usetime"=>time()));
			echo "<script>alert('开通成功');</script>";
		}else{
			echo "<script>alert('开通失败');</script>";
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?>

        <!--main content start-->

            <!--page header end-->


            <!--start page content-->
<div class="row">
<div class="col-md-6">
<div class="panel panel-primary">
   <div class="panel-heading">
   账户充值续费
   </div>
<div class="panel-body">
								<center>
								<form action="?" method="POST">
                                    <div class="form-group has-success">
					                    <label for="demo-vs-scsinput" class="control-label">请输入购买的充值卡密</label>
					                    <input type="text" name="km" id="demo-vs-scsinput" class="form-control">
										<button type="submit" class="btn btn-primary" style="width:100%" onclick="kmcz()"><i class="fa fa-star"></i>   充值 / 续费</button>
										<br/>
										<br/>
<div class="alert alert-info alert-dismissible fade in" role="alert">
                                    <?php echo $userczsm ?>
</div>
				                </div>
								</form>
                                </center>								
<center>
<hr>
<a href="<?php echo $buykami ?>" target="_blank">
<button type="button" class="btn btn-info" style="width:100%" ><i class="fa fa-star"></i>   卡密自助在线购买</button>
</a>
</center>
</div>
</div>
</div>
<div class="col-md-6">
<div class="panel panel-primary">
   <div class="panel-heading">
   官方动态公告
   </div>
<div class="panel-body">
								<center>
<script type="text/javascript" src="<?php echo $usergg ?>"></script>
                                </center>								
</div>
</div>
</div>
</div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-primary padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-users fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
								<h4 class="mv-0">用户名</h4>
                                <div class="text-uppercase"><?php echo $userinfo[_iuser_]?></div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-teal padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-bar-chart fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0">账户状态</h4>
                                <div class="text-uppercase"><?php echo $userinfo["i"] == 1 ? "启用" : "禁用";?></div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-success padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="fa fa-laptop fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0">剩余流量</h4>
                                <div class="text-uppercase"><?php echo round(($userinfo['maxll']-$userinfo['isent']-$userinfo['irecv'])/1024/1024);?> M</div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-indigo padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-clock fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0">到期时间</h4>
                                <div class="text-uppercase"><?php echo date("Y年m月d日",$userinfo["endtime"]);?></div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
            </div>		
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
            <!--Start footer-->
<?php
 include("api_footer.php");
 ?><?php 