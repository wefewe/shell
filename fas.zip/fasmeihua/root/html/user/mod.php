<?php
	if($_GET["act"] == "mod"){
		if($_POST["passnew"] == $_POST["passnew2"]){
			die(json_encode(array("status"=>"error","msg"=>"新旧密码相同，请修改")));
		}else{
			if($_POST["passnew"] == $userinfo[_ipass_]){
				if(trim($_POST["passnew2"]) == ""){
					die(json_encode(array("status"=>"error","msg"=>"密码不得为空")));
				}else{
					if(db("openvpn")->where(["id"=>$userinfo["id"]])->update(["pass"=>$_POST["passnew2"]])){
						die(json_encode(["status"=>"success","msg"=>"密码修改成功，请退出账户重新登录生效！"]));
					}
					die(json_encode(["status"=>"error","msg"=>"无法更新数据到数据库"]));
				}
			}
			die(json_encode(["status"=>"error","msg"=>"当前密码错误"]));
		}
	}else{
		include("api_head.php");
		include("nav.php");

 ?>
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            账户密码修改
                        </div>
                        <div class="panel-body">
	<div class="form-group">
    <label for="name">请输入您的旧密码</label>
    <input type="password" class="form-control" id="passnew" placeholder="">
  </div>
  <div class="form-group">
    <label for="name">请输入您的新密码</label>
    <input type="password" class="form-control" id="passnew2" placeholder="">
  </div>
  <button type="button" class="btn btn-default mod">确认修改</button>
 </div>
 </div>
 </div>
 </div>
         <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
  <script>
  $(function(){
	  $(".mod").click(function(){
		//  alert("修改密码后您必须重新切换账号登录！");
		  $.post(
			"?act=mod",{
				"passnew":$("#passnew").val(),
				"passnew2":$("#passnew2").val()
			},function(data){
				if(data.status == "success"){
					alert("密码修改成功，请退出账户重新登录生效！");
					window.myObj.goLogin();
				}else{
					alert(data.msg);
				}
			},"JSON"
		  );
	  });
  });
  </script>
	<?php
	
	require("api_footer.php");}?><?php 