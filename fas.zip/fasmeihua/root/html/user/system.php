<?php

require dirname(dirname( __FILE__))."/system.php";
if(!$not_to_login)
{
	$username = $_SESSION["user"]["username"];
	$password = $_SESSION["user"]["password"];
	$userinfo = db("openvpn")->where([_iuser_=>$username,_ipass_=>$password])->find();
	if(!$username)
	{
		header("location:login.php?head=no");	
		exit;
	}
}
$servertitle = file_get_contents("../servertitle.txt");
$serverlogo = file_get_contents("../serverlogo.txt");
$usergg = file_get_contents("../usergg.txt");
$buykami = file_get_contents("../buykami.txt");
$userappdown = file_get_contents("../userappdown.txt");
$usertiaokuan = file_get_contents("../usertiaokuan.txt");
$userhelp = file_get_contents("../userhelp.txt");
$userczsm = file_get_contents("../userczsm.txt");
$serverdomain = file_get_contents("../serverdomain.txt");
$servercopy = file_get_contents("../servercopy.txt");
?>