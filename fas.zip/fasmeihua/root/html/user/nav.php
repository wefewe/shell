
        <aside class="float-navigation light-navigation">
            <div class="nano">
                <div class="nano-content">
                    <ul class="metisMenu nav" id="menu">
                        <li class="nav-heading"><span>用户中心菜单</span></li>
                        <li>
                            <a href="../index.php" aria-expanded="true"><i class="icon-home"></i> 官网首页 </a>
                        </li>
                        <li class="active">
                            <a href="index.php" aria-expanded="true"><i class="icon-home"></i> 用户中心首页 </a>
                        </li>
<!--                         <li>
						<a href="widgets.html"><i class="fa fa-diamond"></i> Widgets </a>
						</li> -->
						<li>
                            <a href="buy.php" aria-expanded="true"><i class="icon-basket"></i> 账户充值/续费 </a>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-screen-smartphone"></i> 客户端/APP下载 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="<?php echo $userappdown ?>">安卓APP下载   <span class="label label-info">新版</span></a></li>
                                <li><a href="//itunes.apple.com/us/app/openvpn-connect/id590379981?mt=8" target="_blank">苹果APP下载</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="iosline.php?act=line&key=&username=&password=&location=true" aria-expanded="true"><i class="fa fa-sitemap"></i> IOS线路安装 </a>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="fa fa-clipboard"></i> 帮助中心 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="iosinfo.php">IOS使用教程</a></li>
                                <li><a href="<?php echo $userhelp ?>" target="_blank">新手帮助</a></li>
                            </ul>
                        </li>
						<li>
                            <a href="<?php echo $usertiaokuan ?>" target="_blank" aria-expanded="true"><i class="icon-list"></i> 使用条款 </a>
                        </li>
                        <li class="nav-heading"><span>代理中心菜单</span></li>
                        <li>
                            <a href="../daili/" aria-expanded="true"><i class="fa fa-group"></i> 代理登录 </a>
                        </li>
						<li>
                            <a href="../daili/reg.php" aria-expanded="true"><i class="fa fa-group"></i> 代理注册 </a>
                        </li>
                        <!--<li><a href="landing/index.html" target="_blank" class="bg-primary"><i class="icon-star"></i>Landing page</a></li>-->
                    </ul>
                </div><!--nano content-->
            </div><!--nano scroll end-->
        </aside><?php 