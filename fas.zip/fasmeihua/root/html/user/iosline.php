<?php
include('api_head.php');
include("nav.php");
//include('nav.php');
function get_device_type()
{
 //全部变成小写字母
 $agent = strtolower($_SERVER['HTTP_USER_AGENT']);
 $type = 'other';
 //分别进行判断
 if(strpos($agent, 'iphone') || strpos($agent, 'ipad'))
{
 $type = 'ios';
 } 
  
 if(strpos($agent, 'android'))
{
 $type = 'android';
 }
 return $type;
}
if(get_device_type() == "ios")
{
	include('line.php');
}else{
	echo '<div class="row">';
	echo '<div class="col-sm-12">';
	echo '<div class="panel panel-default">';
	echo '<div class="panel-heading">
                            温馨提示
                        </div>';
	echo '<div class="panel-body">';
	echo '<center>';
	echo '请使用iPhone手机自带的“Safari”浏览器访问本页面进行线路安装！';
	echo '</center>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
}
?>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
 include("api_footer.php");
 ?>

 