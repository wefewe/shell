
        <aside class="float-navigation light-navigation">
            <div class="nano">
                <div class="nano-content">
                    <ul class="metisMenu nav" id="menu">
                        <li class="nav-heading"><span>代理中心菜单</span></li>
                        <li>
                            <a href="../index.php" aria-expanded="true"><i class="icon-home"></i> 官网首页 </a>
                        </li>
                        <li class="active">
                            <a href="index.php" aria-expanded="true"><i class="icon-home"></i> 代理中心首页 </a>
                        </li>
<!--                         <li>
						<a href="widgets.html"><i class="fa fa-diamond"></i> Widgets </a>
						</li> -->
						<li>
                            <a href="order.php" aria-expanded="true"><i class="icon-basket"></i> 账户充值 </a>
                        </li>
						<li>
                            <a href="user_list.php" aria-expanded="true"><i class="icon-users"></i> 用户管理 </a>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="fa fa-bars"></i> 卡密管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="km_list.php">卡密管理/提取</a></li>
                                <li><a href="km_last.php">上次提取记录</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="true"><i class="icon-screen-smartphone"></i> APP软件管理 <span class="fa arrow"></span></a>
                            <ul class="nav-second-level nav" aria-expanded="true">
                                <li><a href="add_gg.php">发布新公告</a></li>
                                <li><a href="list_gg.php">公告管理</a></li>
								<li><a href="kf.php">客服页面设置</a></li>
                            </ul>
                        </li>
                        <li class="nav-heading"><span>用户中心菜单</span></li>
                        <li>
                            <a href="../user/" aria-expanded="true"><i class="fa fa-user"></i> 前往用户中心 </a>
                        </li>
						<li>
                            <a href="../user/reg.php" aria-expanded="true"><i class="fa fa-user"></i> 注册新用户 </a>
                        </li>
                        <!--<li><a href="landing/index.html" target="_blank" class="bg-primary"><i class="icon-star"></i>Landing page</a></li>-->
                    </ul>
                </div><!--nano content-->
            </div><!--nano scroll end-->
        </aside><?php 