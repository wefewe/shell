<?php
$login_allow = true;
require("system.php");
if(ACT == "logout"){
	unset($_SESSION["dl"]);
	header("location:admin.php");
}else{

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>代理中心登录 - <?php echo $servertitle ?></title>

        <!-- Common plugins -->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/bootstrap.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/simple-line-icons.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/font-awesome.min.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/pace.css" rel="stylesheet">
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/jasny-bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/nanoscroller.css">
        <link rel="stylesheet" href="//img.ml.sutuo.club/css/yllmh/20171109/css/metismenu.min.css">
        <!--for checkbox-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/blue.css" rel="stylesheet">
        <!--template css-->
        <link href="//img.ml.sutuo.club/css/yllmh/20171109/css/style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/html5shiv.min.js"></script>
          <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/respond.min.js"></script>
        <![endif]-->
        <style type="text/css">
            html,body{
                height: 100%;
            }
        </style>
    </head>
    <body>
<?php
if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	if(trim($u) == "" || trim($p) == ""){
		echo "<script>alert(\"账户密码不能为空\");</script>";
	}else{
	$admin = db("app_daili")->where(array("name"=>$u,"pass"=>$p,"lock"=>1))->find();
		if($admin){
			if($admin["endtime"] > time()){
				$_SESSION["dl"]["username"] = $u;
				$_SESSION["dl"]["password"] = $p;
				header("location:admin.php");
			}else{
				echo "<script>alert(\"代理身份已经过期\");</script>";
			}
		}else{
			echo "<script>alert(\"密码错误或者尚未激活\");</script>";
		}
	}
}


?>
        <div class="misc-wrapper">
            <div class="misc-content">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                            <div class="misc-header text-center">
                                <img src="<?php echo $serverlogo ?>" style="width:125px" alt="">
                            </div>
                            <div class="misc-box">   
                                <p class="text-center text-uppercase pad-v">代理中心登录</p>
                                <form action="./login.php" method="POST" role="form">
                                    <div class="form-group">                                      
                                        <label class="text-muted" for="exampleuser1">代理帐号</label>
                                        <div class="group-icon">
                                        <input name="user" type="text" placeholder="username" class="form-control input-lg">
                                        <span class="icon-user text-muted icon-input"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="text-muted" for="exampleInputPassword1">代理密码</label>
                                        <div class="group-icon">
                                        <input name="pass" id="inputPassword" type="password" placeholder="password" class="form-control input-lg">
                                        <span class="icon-lock text-muted icon-input"></span>
                                        </div>
                                    </div>
                                    <div class="clearfix">
                                            <button type="submit" class="btn btn-primary" style="width:100%">登录</button>
                                    </div>
									</form>
                                    <hr>
                                    <a href="reg.php" class="btn btn-success" style="width:100%">注册代理帐号</a>
									<p></p>
									<a href="../user/" class="btn btn-warning" style="width:100%">前往用户中心</a>
									<hr>
                            </div>
                            <div class="text-center misc-footer">
<?php echo $servercopy ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Common plugins-->
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/pace.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jasny-bootstrap.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.slimscroll.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.nanoscroller.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/metismenu.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/float-custom.js"></script>
        <!--ichecks-->
    </body>
</html>
<?php 

}
?><?php 