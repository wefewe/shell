<?php
require('head.php');
require('nav.php');
//基本信息加载
$nums = db(_openvpn_)->where(["daili"=>$admin["id"]])->getnums();
$nums2 = db(_openvpn_)->where(["i"=>"1","daili"=>$admin["id"]])->getnums();
$nums3 = db(_openvpn_)->where("endtime<:endtime AND endtime>:start AND i = 1 AND daili=:daili",["endtime"=>time()+24*60*60*3,"start"=>time(),"daili"=>$admin["id"]])->getnums();
?>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-primary padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-users fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
								<h4 class="mv-0"><?php echo $nums?> 个</h4>
                                <div class="text-uppercase">下级用户数</div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-teal padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-bar-chart fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0"><?php echo $nums2?> 个</h4>
                                <div class="text-uppercase">在用用户数</div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-success padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="fa fa-laptop fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0"><?php echo $nums3?> 个</h4>
                                <div class="text-uppercase">即将到期用户数</div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="widget bg-indigo padding-0">
                        <div class="row row-table">
                            <div class="col-xs-4 text-center pv-15 bg-light-dark">
                                <em class="icon-clock fa-3x"></em>
                            </div>
                            <div class="col-xs-8 pv-15 text-center">
                                <h4 class="mv-0"><?php echo date("H:i",time())?></h4>
                                <div class="text-uppercase">系统时间</div>
                            </div>
                        </div>
                    </div><!--end widget-->
                </div><!--end col-->
            </div>
<div class="row">
<div class="col-md-6">
<div class="panel panel-default">
   <div class="panel-heading">
   账户信息一览
   </div>
<div class="panel-body">
<div class="col-md-6 col-sm-6">
                    <div class="widget bg-primary text-center">
                        <h4 class="font-300">账户余额</h4>
                        <h3 class="font-300"><?= $admin["balance"]?>&nbsp;元</h3>
                        <p class="margin-b-0">
                            <i class="fa fa-money"></i>
                        </p>
                    </div><!-- end widget-->
                </div>
<div class="col-md-6 col-sm-6">
                    <div class="widget bg-danger text-center">
                        <h4 class="font-300">提卡折扣</h4>
                        <h3 class="font-300"><?= $admin_ext["per"]?>&nbsp;%</h3>
                        <p class="margin-b-0">
                            <i class="fa fa-tags"></i>
                        </p>
                    </div><!-- end widget-->
                </div>
<div class="col-md-6 col-sm-6">
                    <div class="widget bg-success text-center">
                        <h4 class="font-300">代理级别</h4>
                        <h3 class="font-300"><?= $admin_ext["name"]?></h3>
                        <p class="margin-b-0">
                            <i class="fa fa-vine"></i>
                        </p>
                    </div><!-- end widget-->
                </div>
<div class="col-md-6 col-sm-6">
                    <div class="widget bg-teal text-center">
                        <h4 class="font-300">代理有效期</h4>
                        <h3 class="font-300"><?= date("Y.m.d",$admin["endtime"])?></h3>
                        <p class="margin-b-0">
                            <i class="fa fa-calendar-times-o"></i>
                        </p>
                    </div><!-- end widget-->
                </div>
<div class="col-sm-12">
<a href="order.php">
<button type="button" class="btn btn-info" style="width:100%"><i class="fa fa-money"></i>   代理账户余额充值</button>
</a>
</div>
</div>
</div>
</div>
<div class="col-md-6">
<div class="panel panel-default">
   <div class="panel-heading">
   官方动态公告
   </div>
<div class="panel-body">
								<center>
<script type="text/javascript" src="<?php echo $dailigg ?>"></script>
                                </center>								
</div>
</div>
</div>
</div>		
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
            <!--Start footer-->
<?php
include("footer.php");
 ?><?php 