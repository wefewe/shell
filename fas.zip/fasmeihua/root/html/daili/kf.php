<?php

include('head.php');
include('nav.php');

	if($_GET["act"] == "mod"){
		$db = db('app_daili');
		if($db->where(['id'=>$admin['id']])->update(['content'=>$_POST['content']])){
			tip_success("公告修改成功",$_SERVER['HTTP_REFERER']);
		}else{
			tip_failed("十分抱歉修改失败",$_SERVER['HTTP_REFERER']);
		}
	}else{
		
 ?>
   
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            客服设置
                        </div>
                        <div class="panel-body">
   
 <form role="form" action="?act=mod" method="POST">
  <div class="form-group">
    <label for="name">客服页面的文字内容 支持HTML</label>
    <textarea class="form-control" rows="6" name="content"><?=$admin["content"]?></textarea>
  </div>
  <input type="submit" class="btn btn-default mod" value="确认修改">
  </form>
</div>
</div>
</div>
</div>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php include('footer.php'); };?><?php 