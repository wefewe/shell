<?php
require dirname(dirname( __FILE__))."/system.php";
if(!$login_allow)
{
	$where[] = 'name=:name'; $data[":name"]=$_SESSION["dl"]["username"];
	$where[] = 'pass=:pass'; $data[":pass"]=$_SESSION["dl"]["password"];
	$where[] = 'endtime>:time'; $data[":time"]=time();
	$admin = db("app_daili")->where(implode(" AND ",$where),$data)->find();
	if(!$admin)
	{
		header("location:login.php?head=no");	
		exit;
	}
	$data = null;
	$where = null;
	$admin_ext = db("app_daili_type")->where(["id"=>$admin["type"]])->find();
	define("DID",$admin["id"]);	
}
$servertitle = file_get_contents("../servertitle.txt");
$serverlogo = file_get_contents("../serverlogo.txt");
$usergg = file_get_contents("../usergg.txt");
$buykami = file_get_contents("../buykami.txt");
$dailigg = file_get_contents("../dailigg.txt");
$userappdown = file_get_contents("../userappdown.txt");
$usertiaokuan = file_get_contents("../usertiaokuan.txt");
$userhelp = file_get_contents("../userhelp.txt");
$userczsm = file_get_contents("../userczsm.txt");
$adminqq = file_get_contents("../adminqq.txt");
$serverdomain = file_get_contents("../serverdomain.txt");
$servercopy = file_get_contents("../servercopy.txt");
?>