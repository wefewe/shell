<?php
require('head.php');
require('nav.php');
$_SESSION["token"] = "active";
$_SESSION["order"] = date("YmdHis",time()).rand(10000,99999);
?>

<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            代理账户充值
                        </div>
                        <div class="panel-body">
					 <center>
			  <div class="form-group form-inline">
			  <h4 >账户余额：<?= $admin["balance"]?>  元</h4>
				<label for="name"><B>充值金额：</B></label>
				<br/>
				<center>
			  <input type="text" class="form-control" style="width:300px" id="payVal" placeholder="请输入充值的金额，最低1元起充">
				</center>
			  </div> 
			  <div class="form-group form-inline">
				<label for="name"><B>支付方式：</B></label>
				<br/>
				<div class="btn-group" data-toggle="buttons">
					<label class="btn btn-primary btn-border" style="width:250px">
						<input type="radio" name="pay_type" id="pay_type_1" value="alipay">
						支付宝支付
					</label>
					<br/>
					<label class="btn btn-success btn-border" style="width:250px">
						<input type="radio" name="pay_type" id="pay_type_2" value="wxchat" target="_blank">
						微信扫码付
					</label>
					<br/>
					<label class="btn btn-danger btn-border" style="width:250px">
						<input type="radio" name="pay_type" id="pay_type_3" value="qqpay" target="_blank">
						QQ扫码支付
					</label>
				</div>
			  </div>
			  <a class="btn btn-primary pay" style="width:300px"><i class="icon-ok"></i>&nbsp;确认充值</a>
			  </center>
				</div>	
			</div>
		</div>
</div>
<div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            充值记录
                        </div>
                        <div class="panel-body">
					      <div class="table-responsive">
                          <table class="table table-striped">
<thead>
    <tr>
      <th><center>订单号</center></th>
      <th><center>金额</center></th>
      <th><center>支付方式</center></th>
      <th><center>状态</center></th>
      <th><center>创建时间</center></th>
    </tr>
</thead>
  <tbody>
	<?php
	$db = db("app_order");
	$numrows =$db->where(['uid'=>DID])->getnums();
	$order = $db->where(['uid'=>DID])->fpage($_GET['page'],10)->order('id DESC')->select();
	foreach($order as $vo){
	?>
    <tr>
      <td><center><?= $vo['order']?></center></td>
      <td><center><?= $vo['pay']?>元</center></td>
      <td><center><?= $vo['type']?></center></td>
      <td><center><?= $vo['status'] == 1 ? '<span class="label label-success">充值成功</span>' : '<span class="label label-warning">充值失败</span>';?></center></td>
      <td><center><?= date("Y/m/d H:i:s",$vo['time'])?></center></td>
    </tr>
  	<?php } ?>
		</tbody>
						  </table>
                          </div>
						  <div class="col-sm-12 text-right">
		<?php
		echo create_page_html($numrows,$_GET["page"],10,null);
		?>
		</div>
                        </div>
                    </div>
               </div>
</div>
<div style="display:none">
<a href="do.php" target="_blank" id="newpage">newpage</a>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title" id="myModalLabel">
					确认订单
				</h4>
			</div>
			<div class="modal-body">
				请在新页面中完成支付(支付成功后可能延迟2-3秒到帐)
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
					取消支付
				</button>
				<button type="button" class="btn btn-info yes-to-pay">
					支付完成
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<script>

$(function(){
	$(".pay").click(function(){
		var pay_val = $("#payVal").val();
		var type_val = $("[name='pay_type']:checked").val();
		if(!type_val){
			alert("请选择支付方式");
			return;
		};
		$.ajax({
			type: "POST",
			dataType: "json",
			url: "do.php?do=create_order",
			async: false,//同步请求
			data: {
				pay:pay_val,
				type:type_val
			},
			success: function(data) {
				 if(data.ret == '10000')
				{ 
					 window.open(data.url);
					 $('#myModal').modal('show');
				}else{
					 alert(data.msg);
				}
			},
			error: function(data) {
				alert("正在加载请稍后！");
			}
		});
		//$("#newpage").attr({'href':data.url});
		//$('#myModal').modal('show');
		//$('#newpage')[0].click();		
       
    });
	$(".yes-to-pay").click(function(){
        window.location.reload();
    });  
});
</script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
            <!--Start footer-->
<?php
include("footer.php");
 ?><?php 