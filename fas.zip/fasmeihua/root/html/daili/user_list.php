<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
if($_GET["a"] == "qset"){
	include("qset.php");
	}else{

?>

               <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            发展用户列表
                        </div>
                        <div class="panel-body">
<?php

echo '<form action="user_list.php" method="get" class="form-inline">
  <div class="col-sm-12">
    <input type="text" class="form-control" style="width:100%" name="kw" placeholder="账号">
	<button type="submit" class="btn btn-primary" style="width:100%">搜索</button>&nbsp;
  </div>';
if(!empty($_GET['kw'])) {
	$numrows = db(_openvpn_)->where(array(_iuser_=>$_GET["kw"]))->getnums();
	$where = array(_iuser_=>$_GET["kw"],"daili"=>$admin["id"]);
	$con='
	<div class="col-sm-12">
	<center>
	<a href="#" class="btn btn-success" style="width:100%">平台共有 <b>'.$numrows.'</b> 个账号</a>
	</center>
	</div>&nbsp;';
}else{
	//$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
	$numrows = db(_openvpn_)->where(["daili"=>$admin["id"]])->getnums();
	$where= array("daili"=>$admin["id"]);
	$con='
	<div class="col-sm-12">
	<center>
	<a href="#" class="btn btn-success" style="width:100%">平台共有 <b>'.$numrows.'</b> 个账号</a>
	</center>
	</div>&nbsp;';
}
echo $con;
echo '</form>';

?>
<div class="col-sm-12">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
		  <tr>
		  <th width="50"><center>UID</center></th>
		  <th><center>账号</center></th>
		  <th><center>添加时间</center></th>
		  <th><center>到期时间</center></th>
		  <th><center>剩余流量</center></th>
		  <th><center>总流量</center></th>
		  <th><center>状态</center></th>
		  </tr>
		  </thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
//$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
$rs=db(_openvpn_)->where($where)->limit($offset,$pagesize)->order("id DESC")->select();
$i = 1;
foreach($rs as $res)
{ 
if(date("Y-m-d",$res['starttime']) == date("Y-m-d",time())){
	$p = '&nbsp;<span class="label label-success">今日新增</span>';
}elseif(date("Y-m-d",$res['starttime']) == date("Y-m-d",(time()-24*60*60))){
	$p = '&nbsp;<span class="label label-warning">昨日新增</span>';
}else{
	$p ="";
}

if($res["vip"] == 1){
	$vip = '&nbsp;<span class="label label-success">VIP</span>';
}elseif($res["vip"] == 2){
	$vip = '&nbsp;<span class="label label-warning">VIP2</span>';
}else{
	$vip ="";
}
?>
<tr class="line-id-<?=$res['iuser']?>">
<td><center><?=$res['id']?></center></td>
<td><center><?=$vip?><?=$res['iuser']?><?=$p?></center></td>
<td><center><?=date("Y-m-d",$res['starttime'])?></center></td>
<td><center><?=date("Y-m-d",$res['endtime'])?></center></td>
<td><center><span class="shengyu"><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?></span>MB</center></td>
<td><center><span class="maxll"><?=round(($res['maxll'])/1024/1024)?></span>MB</center></td>
<td><center><?=($res['i']?'开通':'禁用')?></center></td>
</tr>

<?php 
	$i++;
}
?>
          </tbody>
        </table>
</div>
<div class="col-sm-12 text-right">
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="user_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="user_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="user_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="user_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="user_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="user_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
</div>
    </div>
    </div>
	</div>
	</div>
	</div>
	    <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
include("footer.php");
?>
<?php 