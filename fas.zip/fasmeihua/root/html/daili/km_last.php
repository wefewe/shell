<?php
include("head.php");
include("nav.php");
?>
<div class="row">
<div class="col-sm-12">
<div class="panel panel-default">
<div class="panel-heading">卡密上次生成记录</div>
<div class="panel-body">
<?php
echo '<div class="box">';
$km = db("app_kms");
$order = $km->where(["daili"=>$admin["id"]])->order("id DESC")->find();
if($order){
	$list = $km->where(["daili"=>$admin["id"],"addtime"=>$order["addtime"]])->order("id DESC")->select();
	echo "<center><h3>生成时间：".date("Y/m/d H:i:s",$order["addtime"])."</h3></center><br><hr>";
	foreach($list as $vo){
		echo '<center>';
		echo $vo["km"]."<br>";
		echo '</center>';
	}
}
		echo '<hr>';
		echo '<a type="button" class="btn btn-teal" style="width:100%" href="km_list.php">返回卡密列表</a>';
echo "</div>";
?>
</div>
</div>
</div>
</div>
	    <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/jquery.min.js"></script>
        <script src="//img.ml.sutuo.club/css/yllmh/20171109/js/bootstrap.min.js"></script>
<?php
include("footer.php");
?><?php 